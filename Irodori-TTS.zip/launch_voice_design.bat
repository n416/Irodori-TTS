@echo off
echo ========================================================
echo Starting Irodori-TTS Voice Design UI (テキストで声を作成)
echo ========================================================
echo URL: http://localhost:7861
echo 起動するまでしばらくお待ちください...
python -m uv run python gradio_app_voicedesign.py --server-name 0.0.0.0 --server-port 7861
pause
