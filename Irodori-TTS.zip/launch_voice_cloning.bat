@echo off
echo ========================================================
echo Starting Irodori-TTS Voice Cloning UI (お手本音声を使用)
echo ========================================================
echo URL: http://localhost:7860
echo 起動するまでしばらくお待ちください...
python -m uv run python gradio_app.py --server-name 0.0.0.0 --server-port 7860
pause
